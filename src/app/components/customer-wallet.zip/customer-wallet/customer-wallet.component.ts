import { Component, OnInit } from '@angular/core';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { CustHowitWorkComponent } from '../cust-howit-work/cust-howit-work.component';

@Component({
  selector: 'app-customer-wallet',
  templateUrl: './customer-wallet.component.html',
  styleUrls: ['./customer-wallet.component.scss']
})
export class CustomerWalletComponent implements OnInit {
  expandedindex: any = null;
  paymentss: Array<any> = [
    {
      amCost: 0,
      amSale: 0,
      amSave: 0,
      amTotal: 500,
      earn: 50,
      cart: [],
      id: "bDjUjiz0OxImLPAlc5S4",
      invoice: { COD: false, amtRefrCash: 0, useRefrCash: false },
      status: 10,
      journey: "DIRECT",
      storeName: "Fit Foods",
      refr: null,
      ordrTYPE: "CASH",
      userName: "Roshan"
    },
    {
      amCost: 400,
      amSale: 0,
      amSave: 0,
      amTotal: 500,
      earn: 50,
      cart: [],
      id: "bDjUjiz0OxImLPAlc5S4",
      invoice: { COD: false, amtRefrCash: 100, useRefrCash: true },
      status: 10,
      journey: "DIRECT",
      storeName: "Fit Foods",
      refr: null,
      ordrTYPE: "RefrCASH+ONLINE",
      userName: "Roshan",
    },
    {
      amCost: 0,
      amSale: 0,
      amSave: 0,
      amTotal: 500,
      earn: 50,
      cart: [],
      id: "bDjUjiz0OxImLPAlc5S4",
      invoice: { COD: false, amtRefrCash: 0, useRefrCash: false },
      status: 10,
      journey: "F2F",
      storeName: "Fit Foods",
      refr: {
        earn: 25,
        name: "Rati",
        uid: "7ARbHhRULKXaSsWV9A5sRjmAPwB2"
      },
      ordrTYPE: "CASH",
      userName: "Roshan",
    },
    {
      amCost: 400,
      amSale: 0,
      amSave: 0,
      amTotal: 500,
      earn: 50,
      cart: [],
      id: "bDjUjiz0OxImLPAlc5S4",
      invoice: { COD: false, amtRefrCash: 100, useRefrCash: true },
      status: 10,
      journey: "F2F",
      storeName: "Fit Foods",
      refr: {
        earn: 25,
        name: "Rati",
        uid: "7ARbHhRULKXaSsWV9A5sRjmAPwB2"
      },
      ordrTYPE: "RefrCASH+ONLINE",
      userName: "Roshan",
    },
    {
      amCost: 0,
      amSale: 0,
      amSave: 0,
      amTotal: 500,
      status: 10,
      earn: 50,
      cart: [
        {
          Q: 5,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 229,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        },
        {
          Q: 3,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 249,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        }
      ],
      shipCreate: {
        y5Chosen: {
          freight_charge: 40.32,
        }
      },
      logistics: {
        phone: "9167452128",
        typeCat: "food_and_beverages",
        typeOrdr: "DIRECT_ONLINE",
        typeShop: "Both",
        typeSuCat: "sc-food_and_beverages-restaurants"
      },
      id: "bDjUjiz0OxImLPAlc5S4",
      invoice: { COD: true, amtRefrCash: 0, useRefrCash: false },
      journey: "DIRECT",
      storeName: "Fit Foods",
      refr: null,
      ordrTYPE: "COD",
      userName: "Roshan",
    },
    {
      amCost: 0,
      amSale: 0,
      amSave: 0,
      amTotal: 500,
      status: 10,
      earn: 50,
      cart: [
        {
          Q: 5,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 229,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        },
        {
          Q: 3,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 249,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        }
      ],
      shipCreate: {
        y5Chosen: {
          freight_charge: 40.32,
        }
      },
      logistics: {
        phone: "9167452128",
        typeCat: "food_and_beverages",
        typeOrdr: "DIRECT_ONLINE",
        typeShop: "Both",
        typeSuCat: "sc-food_and_beverages-restaurants"
      },
      id: "bDjUjiz0OxImLPAlc5S4",
      invoice: { COD: false, amtRefrCash: 0, useRefrCash: false },
      journey: "DIRECT",
      storeName: "Fit Foods",
      refr: null,
      ordrTYPE: "ONLINE",
      userName: "Roshan",
    },
    {
      amCost: 400,
      amSale: 0,
      amSave: 0,
      amTotal: 500,
      status: 10,
      earn: 50,
      cart: [
        {
          Q: 5,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 229,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        },
        {
          Q: 3,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 249,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        }
      ],
      shipCreate: {
        y5Chosen: {
          freight_charge: 40.32,
        }
      },
      logistics: {
        phone: "9167452128",
        typeCat: "food_and_beverages",
        typeOrdr: "DIRECT_ONLINE",
        typeShop: "Both",
        typeSuCat: "sc-food_and_beverages-restaurants"
      },
      id: "bDjUjiz0OxImLPAlc5S4",
      invoice: { COD: false, amtRefrCash: 100, useRefrCash: true },
      journey: "DIRECT",
      storeName: "Fit Foods",
      refr: null,
      ordrTYPE: "RefrCASH+ONLINE",
      userName: "Roshan",
    },






















    {
      amCost: 0,
      amSale: 0,
      amSave: 0,
      amTotal: 500,
      status: 10,
      earn: 50,
      cart: [
        {
          Q: 5,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 229,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        },
        {
          Q: 3,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 249,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        }
      ],
      shipCreate: {
        y5Chosen: {
          freight_charge: 40.32,
        }
      },
      logistics: {
        phone: "9167452128",
        typeCat: "food_and_beverages",
        typeOrdr: "DIRECT_ONLINE",
        typeShop: "Both",
        typeSuCat: "sc-food_and_beverages-restaurants"
      },
      id: "bDjUjiz0OxImLPAlc5S4",
      invoice: { COD: true, amtRefrCash: 0, useRefrCash: false },
      journey: "F2F",
      storeName: "Fit Foods",
      refr: {
        earn: 25,
        name: "Rati",
        uid: "7ARbHhRULKXaSsWV9A5sRjmAPwB2"
      },
      ordrTYPE: "COD",
      userName: "Roshan",
    },
    {
      amCost: 0,
      amSale: 0,
      amSave: 0,
      amTotal: 500,
      status: 10,
      earn: 50,
      cart: [
        {
          Q: 5,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 229,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        },
        {
          Q: 3,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 249,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        }
      ],
      shipCreate: {
        y5Chosen: {
          freight_charge: 40.32,
        }
      },
      logistics: {
        phone: "9167452128",
        typeCat: "food_and_beverages",
        typeOrdr: "DIRECT_ONLINE",
        typeShop: "Both",
        typeSuCat: "sc-food_and_beverages-restaurants"
      },
      id: "bDjUjiz0OxImLPAlc5S4",
      invoice: { COD: false, amtRefrCash: 0, useRefrCash: false },
      journey: "F2F",
      storeName: "Fit Foods",
      refr: {
        earn: 25,
        name: "Rati",
        uid: "7ARbHhRULKXaSsWV9A5sRjmAPwB2"
      },
      ordrTYPE: "ONLINE",
      userName: "Roshan",
    },
    {
      amCost: 400,
      amSale: 0,
      amSave: 0,
      amTotal: 500,
      status: 10,
      earn: 50,
      cart: [
        {
          Q: 5,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 229,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        },
        {
          Q: 3,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 249,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        }
      ],
      shipCreate: {
        y5Chosen: {
          freight_charge: 40.32,
        }
      },
      logistics: {
        phone: "9167452128",
        typeCat: "food_and_beverages",
        typeOrdr: "DIRECT_ONLINE",
        typeShop: "Both",
        typeSuCat: "sc-food_and_beverages-restaurants"
      },
      id: "bDjUjiz0OxImLPAlc5S4",
      invoice: { COD: false, amtRefrCash: 100, useRefrCash: true },
      journey: "F2F",
      storeName: "Fit Foods",
      refr: {
        earn: 25,
        name: "Rati",
        uid: "7ARbHhRULKXaSsWV9A5sRjmAPwB2"
      },
      ordrTYPE: "RefrCASH+ONLINE",
      userName: "Roshan",
    },
    {
      amCost: 0,
      amSale: 0,
      amSave: 0,
      amTotal: 500,
      status: 10,
      earn: 50,
      cart: [
        {
          Q: 5,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 229,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        },
        {
          Q: 3,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 249,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        }
      ],
      shipCreate: {
        y5Chosen: {
          freight_charge: 40.32,
        }
      },
      logistics: {
        phone: "9167452128",
        typeCat: "food_and_beverages",
        typeOrdr: "DIRECT_ONLINE",
        typeShop: "Both",
        typeSuCat: "sc-food_and_beverages-restaurants"
      },
      id: "bDjUjiz0OxImLPAlc5S4",
      invoice: { COD: false, amtRefrCash: 500, useRefrCash: true },
      journey: "F2F",
      storeName: "Fit Foods",
      refr: {
        earn: 25,
        name: "Rati",
        uid: "7ARbHhRULKXaSsWV9A5sRjmAPwB2"
      },
      ordrTYPE: "RefrCASH",
      userName: "Roshan",
    },
    {
      amCost: 0,
      amSale: 0,
      amSave: 0,
      amTotal: 500,
      status: 10,
      earn: 50,
      cart: [
        {
          Q: 5,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 229,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        },
        {
          Q: 3,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 249,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        }
      ],
      shipCreate: {
        y5Chosen: {
          freight_charge: 40.32,
        }
      },
      logistics: {
        phone: "9167452128",
        typeCat: "food_and_beverages",
        typeOrdr: "DIRECT_ONLINE",
        typeShop: "Both",
        typeSuCat: "sc-food_and_beverages-restaurants"
      },
      id: "bDjUjiz0OxImLPAlc5S4",
      invoice: { COD: false, amtRefrCash: 500, useRefrCash: true },
      journey: "DIRECT",
      storeName: "Fit Foods",
      refr: null,
      ordrTYPE: "RefrCASH",
      userName: "Roshan",
    },
    {
      amCost: 0,
      amSale: 0,
      amSave: 0,
      amTotal: 500,
      status: 10,
      earn: 0,
      cart: [
        {
          Q: 5,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 229,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        },
        {
          Q: 3,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 249,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        }
      ],
      shipCreate: {
        y5Chosen: {
          freight_charge: 40.32,
        }
      },
      logistics: {
        phone: "9167452128",
        typeCat: "food_and_beverages",
        typeOrdr: "DIRECT_ONLINE",
        typeShop: "Both",
        typeSuCat: "sc-food_and_beverages-restaurants"
      },
      id: "bDjUjiz0OxImLPAlc5S4",
      invoice: { COD: true, amtRefrCash: 0, useRefrCash: false },
      journey: "BURN",
      storeName: "Fit Foods",
      refr: null,
      ordrTYPE: "COD",
      userName: "Roshan",
    },
    {
      amCost: 0,
      amSale: 0,
      amSave: 0,
      amTotal: 500,
      status: 10,
      earn: 0,
      cart: [
        {
          Q: 5,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 229,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        },
        {
          Q: 3,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 249,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        }
      ],
      shipCreate: {
        y5Chosen: {
          freight_charge: 40.32,
        }
      },
      logistics: {
        phone: "9167452128",
        typeCat: "food_and_beverages",
        typeOrdr: "DIRECT_ONLINE",
        typeShop: "Both",
        typeSuCat: "sc-food_and_beverages-restaurants"
      },
      id: "bDjUjiz0OxImLPAlc5S4",
      invoice: { COD: false, amtRefrCash: 0, useRefrCash: false },
      journey: "BURN",
      storeName: "Fit Foods",
      refr: null,
      ordrTYPE: "ONLINE",
      userName: "Roshan",
    },
    {
      amCost: 0,
      amSale: 0,
      amSave: 0,
      amTotal: 500,
      status: 10,
      earn: 0,
      cart: [
        {
          Q: 5,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 229,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        },
        {
          Q: 3,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 249,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        }
      ],
      shipCreate: {
        y5Chosen: {
          freight_charge: 40.32,
        }
      },
      logistics: {
        phone: "9167452128",
        typeCat: "food_and_beverages",
        typeOrdr: "DIRECT_ONLINE",
        typeShop: "Both",
        typeSuCat: "sc-food_and_beverages-restaurants"
      },
      id: "bDjUjiz0OxImLPAlc5S4",
      invoice: { COD: false, amtRefrCash: 500, useRefrCash: true },
      journey: "BURN",
      storeName: "Fit Foods",
      refr: null,
      ordrTYPE: "RefrCASH",
      userName: "Roshan",
    },





































    {
      amCost: 400,
      amSale: 0,
      amSave: 0,
      amTotal: 500,
      status: 10,
      earn: 0,
      cart: [
        {
          Q: 5,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 229,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        },
        {
          Q: 3,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 249,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        }
      ],
      shipCreate: {
        y5Chosen: {
          freight_charge: 40.32,
        }
      },
      logistics: {
        phone: "9167452128",
        typeCat: "food_and_beverages",
        typeOrdr: "DIRECT_ONLINE",
        typeShop: "Both",
        typeSuCat: "sc-food_and_beverages-restaurants"
      },
      id: "bDjUjiz0OxImLPAlc5S4",
      invoice: { COD: false, amtRefrCash: 100, useRefrCash: true },
      journey: "BURN",
      storeName: "Fit Foods",
      refr: null,
      ordrTYPE: "RefrCASH+ONLINE",
      userName: "Roshan",
    },


    {
      amCost: 0,
      amSale: 0,
      amSave: 0,
      amTotal: 500,
      status: -100,
      earn: 0,
      cart: [
        {
          Q: 5,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 229,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        },
        {
          Q: 3,
          banners: ['https://firebasestorage.googleapis.com/v0/b/refr/o…=media&token=cb3ed260-d191-4e09-821b-c7d45a3ec8bb'],
          burn: false,
          by: "zn99lfRpB4bDy4KBvu4K1QpSMBk2",
          category: "Dal",
          code: "21069099",
          content: true,
          cost: 249,
          description: "Dal Tadka is a popular Indian lentil dish made with arhar dal (husked & split pigeon pea lentils) or masoor dal (husked & split red lentils). This Dal Tadka recipe gives you a delicious creamy dal with smoked flavors.",
          id: "h25O95gX19QwOYWqprXx",
          price: 299,
          quota: 0,
          reqBurn: false,
          sid: "8B9ozj7aTPvywkIvVWiK",
          sin: { seconds: 1656594533, nanoseconds: 801000000 },
          sold: 0,
          title: "Dal Tadka ",
          upd: { seconds: 1656595043, nanoseconds: 979000000 },
          vX: [],
          variants: [],
          warranty: true
        }
      ],
      shipCreate: {
        y5Chosen: {
          freight_charge: 40.32,
        }
      },
      logistics: {
        phone: "9167452128",
        typeCat: "food_and_beverages",
        typeOrdr: "DIRECT_ONLINE",
        typeShop: "Both",
        typeSuCat: "sc-food_and_beverages-restaurants"
      },
      id: "bDjUjiz0OxImLPAlc5S4",
      invoice: { COD: false, amtRefrCash: 500, useRefrCash: true },
      journey: "BURN",
      storeName: "Fit Foods",
      refr: null,
      ordrTYPE: "RefrCASH",
      userName: "Roshan",
    },


  ]
  constructor(private _bottomSheet: MatBottomSheet) {
    console.log(this.paymentss)
  }


  howitwork() {
    this._bottomSheet.open(CustHowitWorkComponent, {
      panelClass: 'wallethowitworks',
    });
  }

  ngOnInit(): void {
  }

}
